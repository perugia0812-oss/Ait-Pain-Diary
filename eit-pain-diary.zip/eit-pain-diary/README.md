# エイト 痛みの日誌アプリ

## デプロイ手順（Vercel）

### 1. GitHubにアップロード
1. https://github.com にアクセス、ログイン
2. 「New repository」→ リポジトリ名: `eit-pain-diary` → 「Create repository」
3. 「uploading an existing file」→ このフォルダの中身を全部ドラッグ＆ドロップ → 「Commit changes」

### 2. Vercelにデプロイ
1. https://vercel.com にアクセス、GitHubでサインアップ
2. 「New Project」→ `eit-pain-diary` リポジトリを選択
3. Framework Preset: `Create React App`
4. 「Deploy」を押すだけ！

### 3. スマホのホーム画面に追加
- iPhoneの場合：Safariで開く → 共有ボタン → 「ホーム画面に追加」
- Androidの場合：Chromeで開く → メニュー → 「ホーム画面に追加」

## テスト用ログイン情報
- 施設コード: `DEMO001`
- 患者コード: 任意（初回自動登録）

## 技術構成
- フロントエンド: React 18 + PWA
- バックエンド/DB: Supabase（PostgreSQL）
- ホスティング: Vercel（無料）
